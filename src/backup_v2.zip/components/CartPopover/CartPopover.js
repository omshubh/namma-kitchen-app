import React from 'react';

import { Link } from 'react-router-dom';

import Popover from '@mui/material/Popover';
import Typography from '@mui/material/Typography';
import CartDetails from './CartDetails';



const CartPopover = (props) => {
  const { anchorEl, handleClose, cartItems, updateCartItems, showInPage = false } = props;

  const open = Boolean(anchorEl);
  const id = open ? 'simple-popover' : undefined;

  return (
    <Popover
      id={id}
      open={open}
      anchorEl={anchorEl}
      onClose={handleClose}
      anchorOrigin={{
        vertical: 'bottom',
        horizontal: 'left',
      }}
    >
      <Typography sx={{ p: 2 }}>The content of your Cart</Typography>
      <CartDetails cartItems={cartItems} updateCartItems={updateCartItems} handleClose={handleClose} showInPage={showInPage} />
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '20px' }}>
        <Link className="cart-page" to="cart">Checkout</Link>
      </div>
    </Popover>
  );
};

export default CartPopover;