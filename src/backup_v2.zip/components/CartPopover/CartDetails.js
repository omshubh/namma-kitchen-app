import React, { useEffect } from 'react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';

import { useNavigate } from "react-router-dom";

import List from '@mui/material/List';
import Box from '@mui/material/Box';

import ItemDetailsInCart from '../ItemDetailsInCart/ItemDetailsInCart';
import { ListItemButton } from '@mui/material';

function onRemoveFromCartClick(cartItems, item, updateCartItems, handleClose, showInPage) {
  const updatedCartItems = JSON.parse(JSON.stringify(cartItems));
  delete updatedCartItems[item.id];
  if (Object.keys(updatedCartItems).length === 0 && !showInPage) {
    handleClose();
  }
  updateCartItems(updatedCartItems);

}

const updateCartItemQuantity = (itemId, quantity, cartItems, updateCartItems) => {
  const updatedCartItems = JSON.parse(JSON.stringify(cartItems));
  updatedCartItems[itemId].quantity = quantity;
  updateCartItems(updatedCartItems);
}
const CartDetails = (props) => {
  const navigate = useNavigate();
  const { cartItems, updateCartItems, showInPage, handleClose = () => { } } = props;

  useEffect(() => {
    if (Object.keys(cartItems).length === 0) {
      console.log('navigate');
      navigate("/");
    }
  }, [cartItems]);
  const total = Object.values(cartItems).reduce((acc, value) => {
    acc += Number(value.PRICE) * value.quantity;
    return acc;
  }, 0);

  return (
    <>
      {

        showInPage ?
          <AppBar position="static">
            <Toolbar>
              <Typography
                variant="h6"
                noWrap
                component="div"
                sx={{ display: 'block' }}
              >
                Cart page
              </Typography>
            </Toolbar>
          </AppBar> : null
      }

      <Box sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
        <List>
          {
            Object.values(cartItems).map((cartItem, index) => {
              return <ItemDetailsInCart
                key={index}
                cartItem={cartItem}
                onRemoveFromCartClick={(cartItem) => onRemoveFromCartClick(cartItems, cartItem, updateCartItems, handleClose, showInPage)}
                updateCartItemQuantity={(itemId, quantity) => updateCartItemQuantity(itemId, quantity, cartItems, updateCartItems)}
              />
            })
          }
          {

            showInPage ?
              <ListItem
              >
                <ListItemText
                  primary='Total'
                  secondary={`Rs.${total}`}
                  sx={{}}
                />
              </ListItem> : null
          }
        </List>
      </Box>
    </>
  );
};

export default CartDetails;