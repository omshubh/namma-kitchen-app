import React from 'react'

const ItemsMenu = props => {
  const { orders } = props
  return <div className='order-details'>My Orders page</div>
}

export default ItemsMenu
